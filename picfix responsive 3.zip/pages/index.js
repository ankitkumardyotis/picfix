import Head from 'next/head'
import LandingPage from '@/components/landingPage/LandingPage'
import { useTheme } from '@mui/material/styles';
import Switch, { SwitchProps } from '@mui/material/Switch';
import { useMediaQuery } from '@mui/material';

export default function Home({ open, setOpen }) {
  const theme = useTheme();
  const matches = useMediaQuery(theme.breakpoints.up('md'));

  return (
    <>
      <Head>
        <title>PicFix.AI</title>
        <meta name="description" content="Transform your blurry, low-resolution images into stunning works of art with AI" />
        <meta name="viewport" content="width=device-width, initial-scale=1" />
        <link rel="icon" href="/assets/logo.png" />
        <script async src={`https://www.googletagmanager.com/gtag/js?id=${process.env.NEXT_PUBLIC_GOOGLE_ANALYTICS}`}></script>
        <script
          dangerouslySetInnerHTML={{
            __html: `

        window.dataLayer = window.dataLayer || [];
        function gtag(){dataLayer.push(arguments);}
        gtag('js', new Date());
        gtag('config', '${process.env.NEXT_PUBLIC_GOOGLE_ANALYTICS}',{
          page_path: window.location.pathname,

        });
      `,
          }}
        />
      </Head>
      <main >
        <LandingPage open={open} setOpen={setOpen} />

      </main>
    </>
  )
}
