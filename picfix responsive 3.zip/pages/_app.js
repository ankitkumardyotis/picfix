import NavBar from '@/components/NavBar'
import '@/styles/globals.css'
import { useState } from 'react';
import AppContext from '@/components/AppContext';
import Head from 'next/head';


export default function App({ Component, pageProps: { ...pageProps } }) {

  const [fileUrl, setFileUrl] = useState('');
  const [open, setOpen] = useState(false);
  return <>
    <Head>
      <title>PicFix.AI</title>
      <meta name="description" content="Enhance the quality of your Old Image to good one." />
      <meta name="viewport" content="width=device-width, initial-scale=1" />
      <link rel="icon" href="/assets/logo.wepb" />
      <script async src={`https://www.googletagmanager.com/gtag/js?id=${process.env.NEXT_PUBLIC_GOOGLE_ANALYTICS}`}></script>
      <script
        dangerouslySetInnerHTML={{
          __html: `

        window.dataLayer = window.dataLayer || [];
        function gtag(){dataLayer.push(arguments);}
        gtag('js', new Date());
        gtag('config', '${process.env.NEXT_PUBLIC_GOOGLE_ANALYTICS}',{
          page_path: window.location.pathname,

        });
      `,
        }}
      />
    </Head>
    <AppContext.Provider value={{ fileUrl, setFileUrl }}>
      <NavBar open={open} setOpen={setOpen} />
      <Component {...pageProps} />
    </AppContext.Provider>
  </>
}
