import Box from '@mui/material/Box';
import {  CircularProgress, Container, Typography } from '@mui/material';
import React, { useEffect, useState } from 'react';
import ToggleButtonContainer from '@/components/toggleButtonContainer';
import UploaderComponent from '@/components/uploaderComponent';
import OriginalImage from '@/components/originalImage';
import Image from 'next/image';
import AppContext from '@/components/AppContext';
import { useContext } from 'react';
import { ReactCompareSlider, ReactCompareSliderImage } from 'react-compare-slider';
import axios from 'axios';


function RestorePhoto() {
    const context = useContext(AppContext);
    const [restoredPhoto, setRestoredPhoto] = useState("");
    const [clickToSubmitButton, setClickToSubmitButton] = useState(false);
    const [toggleClick, setToggleClick] = useState(false);
    const [loading, setLoading] = useState(false);
    console.log(clickToSubmitButton + "loading");
    const fileUrl = context.fileUrl;



    async function generatePhoto(fileUrl) {
        await new Promise((resolve) => setTimeout(resolve, 500));
        setLoading(true);
        console.log(fileUrl);
        const res = await fetch("/api/generateRemoveObject", {
            method: "POST",
            headers: {
                "Content-Type": "application/json",
            },
            body: JSON.stringify({ imageUrl: fileUrl }),
        });
        let newPhoto = await res.json();
        if (res.status !== 200) {
            setError(newPhoto);
        } else {
            setRestoredPhoto(newPhoto);
        }
        setLoading(false);
    }
    useEffect(() => {
        if (fileUrl && clickToSubmitButton) {
            generatePhoto(fileUrl);
        }
    }, [fileUrl, clickToSubmitButton]);




    const handleSubmitButton = () => {
        setClickToSubmitButton(false);
        setLoading(true);
        generatePhoto(fileUrl);
    }

    //  DownLoad Images 
    const handleDownloadFile = () => {
        // Use Axios to download the file
        axios({
            url: restoredPhoto,
            method: 'GET',
            responseType: 'blob',
        }).then((response) => {
            // Create a link element to trigger the download
            const link = document.createElement('a');
            link.href = window.URL.createObjectURL(new Blob([response.data]));
            link.setAttribute('download', 'image.jpg'); // set the file name
            document.body.appendChild(link);
            link.click();
        }).catch((error) => {
            console.log(error);
        });
    }



    return (
        <>
            <div className='aiModels' style={{ display: 'flex', justifyContent: 'center' }}>
                <Container maxWidth='xl'  >
                    <Typography variant="h2"
                        sx={{ paddingTop: '30px', fontSize: '3rem', fontWeight: '700', marginBottom: '5px', color: ' #000', lineHeight: '50px', textAlign: 'center' }}
                    >
                        Remove Object
                    </Typography>
                    <Typography variant="h6"
                        sx={{ fontWeight: '500', marginBottom: '25px', color: ' #0e0e0e', textAlign: 'center' }}
                    >
                        Enhance your images like a pro!
                    </Typography>

                    <div className='flex-container flex-column'>
                        <div className='flex-container'>
                            {fileUrl && <div style={{ marginTop: '10px', minHeight: '10vh' }}>
                                {restoredPhoto && <ToggleButtonContainer toggleClick={toggleClick} setToggleClick={setToggleClick} />}
                            </div>}
                            {
                                !fileUrl && <div style={{ width: '40rem' }}>
                                    <UploaderComponent />
                                </div>
                            }
                        </div>
                        {/* {!fileUrl && !restoredPhoto ? null : <button style={{ cursor: 'pointer', marginLeft: '100px', marginBottom: '10px', maxWidth: '300px' }} onClick={handleSubmitButton} > use Existing One</button>} */}
                        {!toggleClick ?
                            <>
                                {
                                    fileUrl && <div className='imageContainer box-container'>
                                        {fileUrl && <div className="originalImage">
                                            <OriginalImage />
                                        </div>}
                                        <div className='restoredImage'>
                                            {
                                                fileUrl && loading == false && !restoredPhoto ? <div style={{ textAlign: 'center' }} >
                                                    <div className='submit-btn ' style={{ position: 'absolute', marginLeft: '213px', marginTop: '40px', marginBottom: '20px', display: 'flex', flexDirection: 'column' }}>
                                                        <button style={{ cursor: 'pointer', maxWidth: '300px', zIndex: '1000' }} onClick={handleSubmitButton} >Submit</button>
                                                        <span style={{ marginLeft: '14px', marginTop: '12px' }}>   or</span>
                                                        <br />
                                                    </div>
                                                    <div style={{ position: 'relative' }}>
                                                        <UploaderComponent />
                                                    </div>
                                                </div> : null}
                                            {loading == true &&
                                                <div style={{ display: 'flex', minHeight: '300px', justifyContent: 'center', alignContent: 'center' }} >
                                                    <div style={{ alignSelf: 'center' }}> <CircularProgress color='inherit' /></div>
                                                </div>
                                            }

                                            <div className="restoredImage">
                                                <Image src={restoredPhoto} alt='Restored Image' style={{ borderRadius: '5px', width: '100%', height: '100%', display: !restoredPhoto && 'none', order: 2 }} width={400} height={400} />
                                            </div>
                                        </div>
                                    </div>}
                            </>
                            :
                            <Box maxWidth='sm' minHeight='50vh' sx={{
                                height: '100%', padding: '10px', borderRadius: '5px', boxShadow: ' 0 2px 10px rgba(0, 0, 0, 0.3)'
                            }} >
                                {fileUrl && <ReactCompareSlider
                                    portrait={true}
                                    itemOne={<ReactCompareSliderImage src={fileUrl} alt="Image one" />} itemTwo={<ReactCompareSliderImage src={restoredPhoto} alt="Image two" />} style={{ width: "100%", height: "100%" }} />}
                            </Box>}
                        <Box>
                            {/* {fileUrl && !showExecuteButton && <button style={{ cursor: 'pointer', marginBottom: '10px', marginTop: '30px', maxWidth: '300px' }} onClick={handleSubmitButton} >Execute</button>} */}
                        </Box>
                        {restoredPhoto &&
                            <div className='upload-download-button' style={{ display: 'flex', justifyContent: 'space-between', marginTop: '30px',gap:'30px' }}>
                                <button onClick={() => {
                                    setRestoredPhoto('');
                                    context.setFileUrl('');
                                    setToggleClick(!toggleClick);
                                    window.location.reload();
                                    // setClickToShowUploader(true);
                                }}>Upload New</button>
                                <button style={{ cursor: 'pointer' }} onClick={handleDownloadFile} >Download image</button>
                            </div>
                        }
                    </div>
                </Container >
            </div >
        </>
    )
}

export default RestorePhoto



