"use strict";
exports.id = 947;
exports.ids = [947];
exports.modules = {

/***/ 9907:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);

const AppContext = /*#__PURE__*/ (0,react__WEBPACK_IMPORTED_MODULE_0__.createContext)();
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (AppContext);


/***/ }),

/***/ 1365:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5675);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _AppContext__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(9907);
/* harmony import */ var _mui_icons_material__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(7915);
/* harmony import */ var _mui_icons_material__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material__WEBPACK_IMPORTED_MODULE_4__);






function OriginalImage({ setIsImageLoaded , setOriginalImageHieght , setOriginalImageWidth  }) {
    const context = (0,react__WEBPACK_IMPORTED_MODULE_2__.useContext)(_AppContext__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z);
    const [image, setImage] = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)(null);
    const imageStyle = {
        borderRadius: "5px",
        width: "100%",
        height: "100%",
        order: 1
    };
    const handleFirstDivImageLoad = (event)=>{
        // Update firstDivHeight with the height of the loaded image
        setOriginalImageHieght(event.target.offsetHeight);
        setOriginalImageWidth(event.target.offsetWidth);
    };
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        style: {
            padding: "0"
        },
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_1___default()), {
            src: context.fileUrl,
            alt: "Original Pic",
            style: imageStyle,
            width: 400,
            height: 400,
            onLoad: handleFirstDivImageLoad,
            onLoadStart: ()=>setImage(false + "image is loading is started"),
            onLoadingComplete: ()=>setIsImageLoaded(true + "image is loading")
        })
    });
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (OriginalImage);


/***/ }),

/***/ 7161:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _mui_material_styles__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(8442);
/* harmony import */ var _mui_material_styles__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_mui_material_styles__WEBPACK_IMPORTED_MODULE_3__);




function ToggleButtonContainer({ toggleClick , setToggleClick  }) {
    console.log(toggleClick);
    const handleSwitch = (event)=>{
        // setShowRestored(!showRestored);
        // console.log('Switch toggled:', event);
        "Switch toggled:", event;
        setToggleClick(!toggleClick);
    };
    const IOSSwitch = (0,_mui_material_styles__WEBPACK_IMPORTED_MODULE_3__.styled)((props)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Switch, {
            focusVisibleClassName: ".Mui-focusVisible",
            disableRipple: true,
            ...props
        }))(({ theme  })=>({
            width: 42,
            height: 26,
            marginRight: 17,
            padding: 0,
            "& .MuiSwitch-switchBase": {
                padding: 0,
                margin: 2,
                transitionDuration: "300ms",
                "&.Mui-checked": {
                    transform: "translateX(16px)",
                    color: "#fff",
                    "& + .MuiSwitch-track": {
                        backgroundColor: theme.palette.mode === "dark" ? "#2ECA45" : "#000",
                        opacity: 1,
                        border: 0
                    },
                    "&.Mui-disabled + .MuiSwitch-track": {
                        opacity: 0.5
                    }
                },
                "&.Mui-focusVisible .MuiSwitch-thumb": {
                    color: "#33cf4d",
                    border: "6px solid #fff"
                },
                "&.Mui-disabled .MuiSwitch-thumb": {
                    color: theme.palette.mode === "light" ? theme.palette.grey[100] : theme.palette.grey[600]
                },
                "&.Mui-disabled + .MuiSwitch-track": {
                    opacity: theme.palette.mode === "light" ? 0.7 : 0.3
                }
            },
            "& .MuiSwitch-thumb": {
                boxSizing: "border-box",
                color: "#fff",
                width: 22,
                height: 22
            },
            "& .MuiSwitch-track": {
                borderRadius: 26 / 2,
                backgroundColor: theme.palette.mode === "#000" ? "#000" : "#000",
                opacity: 1,
                transition: theme.transitions.create([
                    "background-color"
                ], {
                    duration: 500
                })
            }
        }));
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: "toggleButton",
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.FormControlLabel, {
            control: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(IOSSwitch, {
                onChange: handleSwitch
            }),
            label: "Show Compare"
        })
    });
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ToggleButtonContainer);


/***/ }),

/***/ 5301:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_uploader__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(9830);
/* harmony import */ var react_uploader__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_uploader__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var uploader__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(879);
/* harmony import */ var uploader__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(uploader__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _AppContext__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(9907);






const uploader = (0,uploader__WEBPACK_IMPORTED_MODULE_3__.Uploader)({
    apiKey:  true ? "public_12a1yJjGMPP7JDUWyq2E8THhybJq" : 0
});
function CustomButton({ onClick  }) {
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
        onClick: onClick,
        children: "Upload New Image"
    });
}
function UploaderComponent({ setRestoredPhoto , setMotionBlurImage  }) {
    const context = (0,react__WEBPACK_IMPORTED_MODULE_1__.useContext)(_AppContext__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z);
    const uploaderOptions = {
        maxFileCount: 1,
        mimeTypes: [
            "image/jpeg",
            "image/png",
            "image/jpg"
        ],
        editor: {
            images: {
                crop: false
            }
        },
        metadata: {
            "myCustomField1": true,
            "myCustomField2": {
                "hello": "world"
            }
        },
        styles: {
            colors: {
                "active": "#000",
                "error": "red",
                "primary": "#000",
                "shade100": "#000",
                "shade200": "#fff",
                "shade300": "#000",
                "shade400": "#000",
                "shade500": "#fff",
                "shade600": "transparent",
                "shade700": "#fff",
                "shade800": "#fff",
                "shade900": "#fff" //upload an image text 
            }
        },
        tags: [
            "example_tag"
        ],
        showFinishButton: false,
        dropzoneRenderer: ({ open  })=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(CustomButton, {
                onClick: open
            })
    };
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        style: {
            padding: "0"
        },
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_uploader__WEBPACK_IMPORTED_MODULE_2__.UploadDropzone, {
            uploader: uploader,
            options: uploaderOptions,
            onUpdate: (files)=>{
                console.log(files);
                context.setFileUrl(files.map((x)=>x.fileUrl).join("\n"));
            },
            onComplete: (files)=>alert(files.map((x)=>x.fileUrl).join("\n")),
            // width="100px"
            height: "45vh",
            // minHeight="10vh"
            border: "5px"
        })
    });
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (UploaderComponent);


/***/ })

};
;